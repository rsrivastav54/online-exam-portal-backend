package com.manipal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="exams")
public class Exam {
	
	@Id
	@Column(name ="q_bank_id")
	private int qBankId;
	
	private String title;
	
	private String q1;
	
	private String op11;
	
	private String op12;
	
	private String op13;
	
	private String op14;
	
	private String a1;
	
	private String q2;
	
	private String op21;
	
	private String op22;
	
	private String op23;
	
	private String op24;
	
	private String a2;
	
	private String q3;
	
	private String op31;
	
	private String op32;
	
	private String op33;
	
	private String op34;
	
	private String a3;
	
	private String q4;
	
	private String op41;
	
	private String op42;
	
	private String op43;
	
	private String op44;
	
	private String a4;
	
	private String q5;
	
	private String op51;
	
	private String op52;
	
	private String op53;
	
	private String op54;
	
	private String a5;
	
	public int getqBankId() {
		return qBankId;
	}
	public void setqBankId(int qBankId) {
		this.qBankId = qBankId;
	}
	public String getQ1() {
		return q1;
	}
	public void setQ1(String q1) {
		this.q1 = q1;
	}
	public String getA1() {
		return a1;
	}
	public void setA1(String a1) {
		this.a1 = a1;
	}
	public String getQ2() {
		return q2;
	}
	public void setQ2(String q2) {
		this.q2 = q2;
	}
	public String getA2() {
		return a2;
	}
	public void setA2(String a2) {
		this.a2 = a2;
	}
	public String getQ3() {
		return q3;
	}
	public void setQ3(String q3) {
		this.q3 = q3;
	}
	public String getA3() {
		return a3;
	}
	public void setA3(String a3) {
		this.a3 = a3;
	}
	public String getQ4() {
		return q4;
	}
	public void setQ4(String q4) {
		this.q4 = q4;
	}
	public String getA4() {
		return a4;
	}
	public void setA4(String a4) {
		this.a4 = a4;
	}
	public String getQ5() {
		return q5;
	}
	public void setQ5(String q5) {
		this.q5 = q5;
	}
	public String getA5() {
		return a5;
	}
	public void setA5(String a5) {
		this.a5 = a5;
	}
	public String getOp11() {
		return op11;
	}
	public void setOp11(String op11) {
		this.op11 = op11;
	}
	public String getOp12() {
		return op12;
	}
	public void setOp12(String op12) {
		this.op12 = op12;
	}
	public String getOp13() {
		return op13;
	}
	public void setOp13(String op13) {
		this.op13 = op13;
	}
	public String getOp14() {
		return op14;
	}
	public void setOp14(String op14) {
		this.op14 = op14;
	}
	public String getOp21() {
		return op21;
	}
	public void setOp21(String op21) {
		this.op21 = op21;
	}
	public String getOp22() {
		return op22;
	}
	public void setOp22(String op22) {
		this.op22 = op22;
	}
	public String getOp23() {
		return op23;
	}
	public void setOp23(String op23) {
		this.op23 = op23;
	}
	public String getOp24() {
		return op24;
	}
	public void setOp24(String op24) {
		this.op24 = op24;
	}
	public String getOp31() {
		return op31;
	}
	public void setOp31(String op31) {
		this.op31 = op31;
	}
	public String getOp32() {
		return op32;
	}
	public void setOp32(String op32) {
		this.op32 = op32;
	}
	public String getOp33() {
		return op33;
	}
	public void setOp33(String op33) {
		this.op33 = op33;
	}
	public String getOp34() {
		return op34;
	}
	public void setOp34(String op34) {
		this.op34 = op34;
	}
	public String getOp41() {
		return op41;
	}
	public void setOp41(String op41) {
		this.op41 = op41;
	}
	public String getOp42() {
		return op42;
	}
	public void setOp42(String op42) {
		this.op42 = op42;
	}
	public String getOp43() {
		return op43;
	}
	public void setOp43(String op43) {
		this.op43 = op43;
	}
	public String getOp44() {
		return op44;
	}
	public void setOp44(String op44) {
		this.op44 = op44;
	}
	public String getOp51() {
		return op51;
	}
	public void setOp51(String op51) {
		this.op51 = op51;
	}
	public String getOp52() {
		return op52;
	}
	public void setOp52(String op52) {
		this.op52 = op52;
	}
	public String getOp53() {
		return op53;
	}
	public void setOp53(String op53) {
		this.op53 = op53;
	}
	public String getOp54() {
		return op54;
	}
	public void setOp54(String op54) {
		this.op54 = op54;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
	

}
